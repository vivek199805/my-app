import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payoutprocess',
  templateUrl: './payoutprocess.component.html',
  styleUrls: ['./payoutprocess.component.css']
})
export class PayoutprocessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
