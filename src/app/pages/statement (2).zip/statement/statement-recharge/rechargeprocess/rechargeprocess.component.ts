import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rechargeprocess',
  templateUrl: './rechargeprocess.component.html',
  styleUrls: ['./rechargeprocess.component.css']
})
export class RechargeprocessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
