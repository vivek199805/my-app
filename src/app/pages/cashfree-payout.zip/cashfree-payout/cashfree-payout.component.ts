import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cashfree-payout',
  templateUrl: './cashfree-payout.component.html',
  styleUrls: ['./cashfree-payout.component.css']
})
export class CashfreePayoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
